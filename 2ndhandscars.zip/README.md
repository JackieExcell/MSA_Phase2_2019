Our business problem is that we want to know the new market situation of second-hand cars in New Zealand, what aspects affect the car prices. We assume that car prices are influenced by ages of the vehicles, brands, car models, the km, liters of the cars, fuel types, car types, discounts, NZ new or not, private sellers or not and locations of the cars.

This project is divided into four parts:

Firstly, I scraped the treadme motor website. I got 3500 records with 15 variables. It includes the variables in our assumption. Refer to the python code file "Web-scraper.ipynb", and the datasets after scraped "trademecars.csv".

Secondly, I used regular expression functions to clean, impute and manipulate using R and Excel. Then, I fitted three models in R, compared the models and got some results. Refer to R markdown "Data clean and modelling.rmd" and pdf output "Data-clean-and-modelling.pdf".
Also created two csv files "brandcount.csv" and "cars2.csv", and one Excel file "brand_country.xlsx".

Thirdly, I used Power BI to visualize the data sources with the three relational datasets. Refer to Power BI outputs "report 1.pbix", "report 2.pbix", "report 3.pbix" ,"trademe cars - Power BI dashboard1.pdf" and "trademe cars - Power BI dashboard2.pdf".

Last but not least, refer to "Analysis report.pdf".